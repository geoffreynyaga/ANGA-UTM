﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","ar",{title:"منتقي الألوان",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"مجموعات ألوان معرفة مسبقا",config:"قص السطر إلى الملف config.js"});