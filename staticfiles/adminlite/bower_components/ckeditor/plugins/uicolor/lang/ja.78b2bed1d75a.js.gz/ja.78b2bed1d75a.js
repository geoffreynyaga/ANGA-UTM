﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","ja",{title:"UIカラーピッカー",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"既定カラーセット",config:"この文字列を config.js ファイルへ貼り付け"});