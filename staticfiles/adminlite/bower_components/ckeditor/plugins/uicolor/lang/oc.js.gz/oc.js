﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","oc",{title:"Selector de color",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Paletas de colors predefinidas",config:"Pegatz aqueste tèxte dins vòstre fichièr config.js"});