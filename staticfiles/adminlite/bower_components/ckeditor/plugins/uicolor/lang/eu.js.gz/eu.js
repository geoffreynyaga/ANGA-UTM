﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","eu",{title:"EI kolore-hautatzailea",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Aurrez definitutako kolore multzoak",config:"Itsatsi kate hau zure config.js fitxategian"});