﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","zh",{title:"預留位置屬性",toolbar:"建立預留位置",name:"Placeholder 名稱",invalidName:"「預留位置」不可為空白且不可包含以下字元：[, ], \x3c, \x3e",pathName:"預留位置"});