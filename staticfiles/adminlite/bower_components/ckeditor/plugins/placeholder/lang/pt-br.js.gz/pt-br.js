﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","pt-br",{title:"Propriedades do Espaço Reservado",toolbar:"Criar Espaço Reservado",name:"Nome do Espaço Reservado",invalidName:"O espaço reservado não pode estar vazio e não pode conter nenhum dos seguintes caracteres:  [, ], \x3c, \x3e",pathName:"Espaço Reservado"});